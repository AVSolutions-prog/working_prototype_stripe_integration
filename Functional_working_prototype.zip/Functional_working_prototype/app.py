from flask import session, Flask, render_template, request, jsonify, url_for, redirect
import bcrypt
import base64
import cv2
import os
import numpy as np
from utils import detect_img, ext_face, face_embed, register_user, load_user_by_email, verify_face
from database import initialize_db, load_payment_methods_by_user_id
import stripe

app = Flask(__name__)
app.secret_key = os.urandom(24)
initialize_db()




stripe.api_key = "sk_test_51Q2ZGH055NWWURZmblCVBBHs71JCpyl72q8bb8r7bGGr4PfNWITfHwjjYrhuLXvWHbwjAh0HQkuOS1Ojo8I0lapL00qPg47n7K"

from utils import detect_img, ext_face, face_embed, register_user, load_user_by_email, verify_face
from database import initialize_db, load_payment_methods_by_user_id


def decode_image(image_data):
    """Decode base64 image data to a usable NumPy array (BGR format for OpenCV)."""
    try:
        if ',' in image_data:
            _, base64_data = image_data.split(',', 1)
        else:
            base64_data = image_data
            
        image_bytes = base64.b64decode(base64_data)
        np_arr = np.frombuffer(image_bytes, np.uint8)
        img = cv2.imdecode(np_arr, cv2.IMREAD_COLOR)
        
        if img is None:
            raise ValueError("Decoded image is None. Check base64 encoding.")
        
        return img
    except Exception as e:
        print(f"Error decoding image: {e}")
        return None

@app.route('/')
def index():
    return render_template('welcome.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'GET':
        return render_template('register.html')
    
    try:
        data = request.get_json()
        name = data.get('name')
        email = data.get('email')
        password = data.get('password')
        face_data = data.get('face_data')
        payment_methods = data.get('payment_methods')

        if not (name and email and password and face_data and payment_methods):
            return jsonify({'status': 'fail', 'message': 'All fields are required'}), 400

        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        faces = detect_img(image)
        if not faces:
            return jsonify({'status': 'fail', 'message': 'No face detected'}), 400
        
        face_image = ext_face(image, faces[0]['box'])
        embedding = face_embed(face_image)

        user_id = register_user(name, email, password, embedding, payment_methods)
        
        if user_id:
            # Return success with a redirect URL
            return jsonify({'status': 'success', 'redirect_url': url_for('registration_success')})
        else:
            return jsonify({'status': 'fail', 'message': 'Registration failed. Please try again.'}), 500

    except Exception as e:
        print(f"Error during registration: {e}")
        return jsonify({'status': 'fail', 'message': 'Registration failed. Please try again.'}), 500

@app.route('/registration_success')
def registration_success():
    return render_template('success.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'GET':
        return render_template('login.html')

    try:
        email = request.form.get('email')
        password = request.form.get('password')
        face_data = request.form.get('face_data')

        user = load_user_by_email(email)
        if user is None:
            return jsonify({'status': 'fail', 'message': 'User not found. Please register.'}), 400
        
        user_id, name, _, stored_password = user
        if not bcrypt.checkpw(password.encode('utf-8'), stored_password):
            return jsonify({'status': 'fail', 'message': 'Invalid password'}), 400

        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        if verify_face(user_id, image):
            session['user_id'] = user_id
            return jsonify({'status': 'success', 'redirect_url': url_for('products')})
        else:
            return jsonify({'status': 'fail', 'message': 'Face verification failed. Login denied.'}), 400

    except Exception as e:
        print(f"Error during login: {e}")
        return jsonify({'status': 'fail', 'message': 'Login failed. Please try again.'}), 500


@app.route('/products')
def products():
    return render_template('products.html')

@app.route('/checkout', methods=['GET'])
def checkout():
    user_id = session.get('user_id')
    if user_id:
        print(f"User ID in session: {user_id}")
        payment_methods = load_payment_methods_by_user_id(user_id)
        print(f"Payment methods retrieved for user {user_id}: {payment_methods}")
    else:
        print("No user logged in")
        payment_methods = []
        return redirect(url_for('login'))
    return render_template('checkout.html', payment_methods=payment_methods, user_id=user_id)



@app.route('/checkout_verification', methods=['POST'])
def checkout_verification():
    try:
        user_id = request.form.get('user_id')
        face_data = request.form.get('face_data')
        payment_method_id = request.form.get('payment_method_id')

        # Decode the face image from base64 to an image
        image = decode_image(face_data)
        if image is None:
            return jsonify({'status': 'fail', 'message': 'Invalid image data'}), 400

        # Verify the captured face with the registered face
        if verify_face(user_id, image):
            # Face matched, create Stripe checkout session
            session = stripe.checkout.Session.create(
                payment_method_types=['card'],
                line_items=[{
                    'price_data': {
                        'currency': 'usd',
                        'product_data': {
                            'name': 'Your Product Name',
                        },
                        'unit_amount': 1000,  # Amount in cents
                    },
                    'quantity': 1,
                }],
                mode='payment',
                success_url=url_for('payment_success', _external=True),
                cancel_url=url_for('checkout', _external=True),
            )
            # Redirect to Stripe checkout page
            return jsonify({'status': 'success', 'redirect_url': session.url})
        else:
            # Face verification failed
            return jsonify({'status': 'fail', 'message': 'Face verification failed. Transaction denied.'}), 400

    except Exception as e:
        print(f"Error during face verification at checkout: {e}")
        return jsonify({'status': 'fail', 'message': 'Verification failed. Please try again.'}), 500
    

@app.route('/payment_success')
def payment_success():
    return render_template('payment_success.html')

if __name__ == "__main__":
    app.run(debug=True)

